import { BrowserRouter, Routes, Route } from 'react-router';
import { ThemeProvider } from './context/ThemeContext';
import { Sidebar } from './components/Layout/Sidebar';
import { TopBar } from './components/Layout/TopBar';
import { FloatingAI } from './components/FloatingAI';
import { Dashboard } from './pages/Dashboard';
import { SearchPage } from './pages/SearchPage';
import { AIPlanner } from './pages/AIPlanner';
import { TripDashboard } from './pages/TripDashboard';
import { Collaborate } from './pages/Collaborate';
import { Toaster } from 'react-hot-toast';

export default function App() {
  return (
    <ThemeProvider>
      <BrowserRouter>
        <div className="flex h-screen bg-gray-50 dark:bg-gray-950 transition-colors duration-200">
          <Sidebar />
          
          <div className="flex-1 ml-64 flex flex-col">
            <TopBar />
            
            <main className="flex-1 overflow-auto">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/search" element={<SearchPage />} />
                <Route path="/explore" element={<SearchPage />} />
                <Route path="/trips" element={<TripDashboard />} />
                <Route path="/budget" element={<TripDashboard />} />
                <Route path="/collaborate" element={<Collaborate />} />
                <Route path="/ai-planner" element={<AIPlanner />} />
                <Route path="/settings" element={<Dashboard />} />
              </Routes>
            </main>
          </div>

          <FloatingAI />
        </div>
        
        <Toaster
          position="top-right"
          toastOptions={{
            className: 'dark:bg-gray-800 dark:text-white',
            duration: 3000,
          }}
        />
      </BrowserRouter>
    </ThemeProvider>
  );
}