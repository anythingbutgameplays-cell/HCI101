import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Plane, Clock, Circle } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';

interface FlightCardProps {
  airline: string;
  logo: string;
  departure: string;
  arrival: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  stops: number;
  price: number;
  dealType?: string;
}

export function FlightCard({
  airline,
  logo,
  departure,
  arrival,
  departureTime,
  arrivalTime,
  duration,
  stops,
  price,
  dealType
}: FlightCardProps) {
  const [showRedirectModal, setShowRedirectModal] = useState(false);

  const handleBooking = () => {
    setShowRedirectModal(true);
    setTimeout(() => {
      window.open('https://www.skyscanner.com', '_blank');
      setShowRedirectModal(false);
    }, 2000);
  };

  return (
    <>
      <Card className="p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6 flex-1">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                <span className="text-2xl">{logo}</span>
              </div>
              <div>
                <p className="font-semibold">{airline}</p>
                {dealType && (
                  <Badge variant="secondary" className="mt-1">
                    {dealType}
                  </Badge>
                )}
              </div>
            </div>

            <div className="flex items-center gap-6 flex-1">
              <div className="text-center">
                <p className="text-2xl font-bold">{departureTime}</p>
                <p className="text-sm text-gray-500">{departure}</p>
              </div>

              <div className="flex-1 flex flex-col items-center">
                <div className="flex items-center gap-2 w-full">
                  <Circle className="w-2 h-2 fill-current" />
                  <div className="flex-1 h-px bg-gray-300 relative">
                    <Plane className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 text-blue-600" />
                  </div>
                  <Circle className="w-2 h-2 fill-current" />
                </div>
                <div className="flex items-center gap-2 mt-1 text-sm text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{duration}</span>
                  <span className="text-gray-400">•</span>
                  <span>{stops === 0 ? 'Nonstop' : `${stops} stop${stops > 1 ? 's' : ''}`}</span>
                </div>
              </div>

              <div className="text-center">
                <p className="text-2xl font-bold">{arrivalTime}</p>
                <p className="text-sm text-gray-500">{arrival}</p>
              </div>
            </div>
          </div>

          <div className="text-right ml-6">
            <p className="text-3xl font-bold text-blue-600">${price}</p>
            <p className="text-sm text-gray-500 mb-3">per person</p>
            <Button onClick={handleBooking} size="lg" className="w-full">
              View Deal
            </Button>
          </div>
        </div>
      </Card>

      <Dialog open={showRedirectModal} onOpenChange={setShowRedirectModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Redirecting to Skyscanner</DialogTitle>
            <DialogDescription>
              You're being redirected to complete your booking on Skyscanner.com
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center py-6">
            <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
            <p className="mt-4 text-gray-600">Please wait...</p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
