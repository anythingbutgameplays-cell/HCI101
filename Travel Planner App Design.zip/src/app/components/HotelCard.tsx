import { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Star, MapPin, Wifi, Coffee, Wind, Waves } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';

interface HotelCardProps {
  name: string;
  image: string;
  location: string;
  rating: number;
  reviews: number;
  amenities: string[];
  price: number;
  dealType?: string;
}

export function HotelCard({
  name,
  image,
  location,
  rating,
  reviews,
  amenities,
  price,
  dealType
}: HotelCardProps) {
  const [showRedirectModal, setShowRedirectModal] = useState(false);

  const handleBooking = () => {
    setShowRedirectModal(true);
    setTimeout(() => {
      window.open('https://www.booking.com', '_blank');
      setShowRedirectModal(false);
    }, 2000);
  };

  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case 'wifi':
        return <Wifi className="w-4 h-4" />;
      case 'breakfast':
        return <Coffee className="w-4 h-4" />;
      case 'ac':
        return <Wind className="w-4 h-4" />;
      case 'pool':
        return <Waves className="w-4 h-4" />;
      default:
        return null;
    }
  };

  return (
    <>
      <Card className="overflow-hidden hover:shadow-xl transition-all group">
        <div className="relative h-56 overflow-hidden">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
          {dealType && (
            <Badge className="absolute top-3 right-3 bg-orange-500">
              {dealType}
            </Badge>
          )}
        </div>
        <div className="p-5">
          <div className="flex items-start justify-between mb-2">
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-1">{name}</h3>
              <div className="flex items-center text-sm text-gray-600 mb-2">
                <MapPin className="w-4 h-4 mr-1" />
                {location}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-1">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${
                    i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-gray-600">({reviews} reviews)</span>
          </div>

          <div className="flex gap-2 mb-4 flex-wrap">
            {amenities.map((amenity) => (
              <Badge key={amenity} variant="outline" className="flex items-center gap-1">
                {getAmenityIcon(amenity)}
                {amenity}
              </Badge>
            ))}
          </div>

          <div className="flex items-end justify-between pt-4 border-t">
            <div>
              <p className="text-sm text-gray-600">From</p>
              <p className="text-2xl font-bold text-blue-600">${price}</p>
              <p className="text-xs text-gray-500">per night</p>
            </div>
            <Button onClick={handleBooking} size="lg">
              Book Now
            </Button>
          </div>
        </div>
      </Card>

      <Dialog open={showRedirectModal} onOpenChange={setShowRedirectModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Redirecting to Booking.com</DialogTitle>
            <DialogDescription>
              You're being redirected to complete your reservation on Booking.com
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col items-center py-6">
            <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
            <p className="mt-4 text-gray-600">Please wait...</p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
