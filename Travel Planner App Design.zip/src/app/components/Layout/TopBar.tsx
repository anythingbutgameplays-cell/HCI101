import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '../ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '../ui/popover';
import { Search, Bell, TrendingDown, MapPin, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const popularDestinations = [
  { name: 'Paris, France', type: 'Popular' },
  { name: 'Tokyo, Japan', type: 'Popular' },
  { name: 'Bali, Indonesia', type: 'Trending' },
  { name: 'New York, USA', type: 'Popular' },
  { name: 'Dubai, UAE', type: 'Trending' },
];

const recentSearches = [
  'Paris, France',
  'London, UK',
  'Barcelona, Spain',
];

interface Notification {
  id: number;
  type: 'price-drop' | 'booking' | 'alert';
  title: string;
  message: string;
  time: string;
}

const notifications: Notification[] = [
  {
    id: 1,
    type: 'price-drop',
    title: 'Price Alert',
    message: 'Flight to Paris dropped by $45',
    time: '2h ago'
  },
  {
    id: 2,
    type: 'alert',
    title: 'Trip Reminder',
    message: 'Tokyo trip in 15 days',
    time: '5h ago'
  },
];

export function TopBar() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const handleSearch = (destination: string) => {
    setSearchQuery('');
    setShowSearchResults(false);
    navigate(`/search?destination=${encodeURIComponent(destination)}`);
  };

  return (
    <div className="h-16 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 flex items-center px-6 gap-4 sticky top-0 z-40 backdrop-blur-lg bg-white/80 dark:bg-gray-900/80 transition-colors duration-200">
      {/* Search Bar */}
      <div className="flex-1 max-w-2xl relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            type="text"
            placeholder="Search destinations, flights, hotels..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setShowSearchResults(e.target.value.length > 0);
            }}
            onFocus={() => setShowSearchResults(searchQuery.length > 0)}
            className="pl-10 h-11 bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 focus:bg-white dark:focus:bg-gray-900"
          />
        </div>

        <AnimatePresence>
          {showSearchResults && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-full mt-2 w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl shadow-2xl overflow-hidden z-50"
            >
              <div className="p-4 space-y-4">
                {/* Recent Searches */}
                {searchQuery.length === 0 && recentSearches.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2 flex items-center gap-2">
                      <Clock className="w-3 h-3" />
                      Recent Searches
                    </p>
                    <div className="space-y-1">
                      {recentSearches.map((search) => (
                        <button
                          key={search}
                          onClick={() => handleSearch(search)}
                          className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg transition-colors flex items-center gap-3"
                        >
                          <MapPin className="w-4 h-4 text-gray-400" />
                          <span className="text-sm text-gray-700 dark:text-gray-300">{search}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Popular Destinations */}
                <div>
                  <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">
                    {searchQuery ? 'Suggestions' : 'Popular Destinations'}
                  </p>
                  <div className="space-y-1">
                    {popularDestinations
                      .filter(dest => 
                        !searchQuery || dest.name.toLowerCase().includes(searchQuery.toLowerCase())
                      )
                      .slice(0, 5)
                      .map((dest) => (
                        <button
                          key={dest.name}
                          onClick={() => handleSearch(dest.name)}
                          className="w-full text-left px-3 py-2 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg transition-colors flex items-center justify-between"
                        >
                          <div className="flex items-center gap-3">
                            <MapPin className="w-4 h-4 text-gray-400" />
                            <span className="text-sm text-gray-700 dark:text-gray-300">{dest.name}</span>
                          </div>
                          <Badge variant={dest.type === 'Trending' ? 'default' : 'secondary'} className="text-xs">
                            {dest.type}
                          </Badge>
                        </button>
                      ))}
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="pt-2 border-t border-gray-200 dark:border-gray-800">
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start text-blue-600 dark:text-blue-400"
                    onClick={() => {
                      setShowSearchResults(false);
                      navigate('/search');
                    }}
                  >
                    Advanced Search →
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Notifications */}
      <Popover open={showNotifications} onOpenChange={setShowNotifications}>
        <PopoverTrigger>
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="w-5 h-5" />
            {notifications.length > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-0" align="end">
          <div className="p-4 border-b border-gray-200 dark:border-gray-800">
            <h3 className="font-semibold text-gray-900 dark:text-white">Notifications</h3>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors border-b border-gray-100 dark:border-gray-800 last:border-0"
              >
                <div className="flex items-start gap-3">
                  {notif.type === 'price-drop' && (
                    <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center">
                      <TrendingDown className="w-5 h-5 text-green-600 dark:text-green-400" />
                    </div>
                  )}
                  {notif.type === 'alert' && (
                    <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                      <Bell className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                  )}
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white">{notif.title}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{notif.message}</p>
                    <p className="text-xs text-gray-400 mt-1">{notif.time}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="p-3 border-t border-gray-200 dark:border-gray-800">
            <Button variant="ghost" className="w-full text-sm">
              View all notifications
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
