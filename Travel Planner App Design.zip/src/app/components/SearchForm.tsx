import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Calendar } from './ui/calendar';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { MapPin, Calendar as CalendarIcon, Users, Search } from 'lucide-react';
import { format } from 'date-fns';

export function SearchForm() {
  const navigate = useNavigate();
  const [destination, setDestination] = useState('');
  const [checkIn, setCheckIn] = useState<Date>();
  const [checkOut, setCheckOut] = useState<Date>();
  const [travelers, setTravelers] = useState('2');
  const [searchType, setSearchType] = useState<'flights' | 'hotels'>('flights');

  const handleSearch = () => {
    if (destination) {
      if (searchType === 'flights') {
        navigate(`/flights?destination=${encodeURIComponent(destination)}&travelers=${travelers}`);
      } else {
        navigate(`/hotels?destination=${encodeURIComponent(destination)}&travelers=${travelers}`);
      }
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-4xl mx-auto">
      <div className="flex gap-4 mb-6">
        <Button
          variant={searchType === 'flights' ? 'default' : 'outline'}
          onClick={() => setSearchType('flights')}
          className="flex-1"
        >
          ✈️ Flights
        </Button>
        <Button
          variant={searchType === 'hotels' ? 'default' : 'outline'}
          onClick={() => setSearchType('hotels')}
          className="flex-1"
        >
          🏨 Hotels
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="lg:col-span-2">
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Where to?"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="pl-10 h-12"
            />
          </div>
        </div>

        <Popover>
          <PopoverTrigger className="h-12 w-full">
            <Button variant="outline" className="h-12 w-full justify-start text-left">
              <CalendarIcon className="mr-2 h-5 w-5 text-gray-400" />
              {checkIn ? format(checkIn, 'MMM dd') : 'Check-in'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar
              mode="single"
              selected={checkIn}
              onSelect={setCheckIn}
              initialFocus
            />
          </PopoverContent>
        </Popover>

        <Popover>
          <PopoverTrigger className="h-12 w-full">
            <Button variant="outline" className="h-12 w-full justify-start text-left">
              <CalendarIcon className="mr-2 h-5 w-5 text-gray-400" />
              {checkOut ? format(checkOut, 'MMM dd') : 'Check-out'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar
              mode="single"
              selected={checkOut}
              onSelect={setCheckOut}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        <div className="relative">
          <Users className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400 pointer-events-none" />
          <Select value={travelers} onValueChange={setTravelers}>
            <SelectTrigger className="pl-10 h-12">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 Traveler</SelectItem>
              <SelectItem value="2">2 Travelers</SelectItem>
              <SelectItem value="3">3 Travelers</SelectItem>
              <SelectItem value="4">4 Travelers</SelectItem>
              <SelectItem value="5">5+ Travelers</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button onClick={handleSearch} className="h-12 text-lg" size="lg">
          <Search className="mr-2 h-5 w-5" />
          Search {searchType === 'flights' ? 'Flights' : 'Hotels'}
        </Button>
      </div>
    </div>
  );
}