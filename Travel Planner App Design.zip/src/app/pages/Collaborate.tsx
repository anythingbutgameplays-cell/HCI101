import { useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import {
  Users,
  UserPlus,
  Share2,
  MessageSquare,
  ThumbsUp,
  ThumbsDown,
  Link as LinkIcon,
  Mail,
  Copy,
  Check
} from 'lucide-react';
import toast from 'react-hot-toast';
import { motion } from 'motion/react';

const tripMembers = [
  {
    id: 1,
    name: 'Sarah Johnson',
    email: 'sarah@email.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    role: 'Organizer',
    status: 'online'
  },
  {
    id: 2,
    name: 'Mike Chen',
    email: 'mike@email.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    role: 'Member',
    status: 'online'
  },
  {
    id: 3,
    name: 'Emily Davis',
    email: 'emily@email.com',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emily',
    role: 'Member',
    status: 'offline'
  },
];

const tripProposals = [
  {
    id: 1,
    type: 'hotel',
    proposedBy: 'Sarah Johnson',
    item: 'Grand Palace Hotel',
    price: 299,
    votes: { up: 2, down: 0 },
    comments: 3,
    userVote: null as 'up' | 'down' | null
  },
  {
    id: 2,
    type: 'activity',
    proposedBy: 'Mike Chen',
    item: 'Eiffel Tower Summit Tour',
    price: 55,
    votes: { up: 3, down: 0 },
    comments: 1,
    userVote: null as 'up' | 'down' | null
  },
  {
    id: 3,
    type: 'restaurant',
    proposedBy: 'Emily Davis',
    item: 'Le Jules Verne Restaurant',
    price: 120,
    votes: { up: 1, down: 1 },
    comments: 2,
    userVote: null as 'up' | 'down' | null
  },
];

const comments = [
  {
    id: 1,
    proposalId: 1,
    author: 'Mike Chen',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Mike',
    text: 'Great choice! The location is perfect.',
    timestamp: '2h ago'
  },
  {
    id: 2,
    proposalId: 1,
    author: 'Emily Davis',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emily',
    text: 'Love the rooftop pool!',
    timestamp: '1h ago'
  },
];

export function Collaborate() {
  const [copied, setCopied] = useState(false);
  const [proposals, setProposals] = useState(tripProposals);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');

  const tripLink = 'https://travelplan.app/trip/abc123';

  const copyLink = () => {
    navigator.clipboard.writeText(tripLink);
    setCopied(true);
    toast.success('Link copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const shareToWhatsApp = () => {
    const text = `Join our trip planning! ${tripLink}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleVote = (proposalId: number, voteType: 'up' | 'down') => {
    setProposals(proposals.map(p => {
      if (p.id === proposalId) {
        const currentVote = p.userVote;
        let newVotes = { ...p.votes };
        let newUserVote: 'up' | 'down' | null = voteType;

        // Remove previous vote
        if (currentVote === 'up') newVotes.up--;
        if (currentVote === 'down') newVotes.down--;

        // Add new vote if different
        if (currentVote === voteType) {
          newUserVote = null;
        } else {
          if (voteType === 'up') newVotes.up++;
          if (voteType === 'down') newVotes.down++;
        }

        return { ...p, votes: newVotes, userVote: newUserVote };
      }
      return p;
    }));
  };

  const sendInvite = () => {
    if (inviteEmail) {
      toast.success(`Invitation sent to ${inviteEmail}!`);
      setInviteEmail('');
      setShowInviteModal(false);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              Collaborate on Trip
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Plan together with friends and family
            </p>
          </div>
          
          <Dialog open={showInviteModal} onOpenChange={setShowInviteModal}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="w-5 h-5 mr-2" />
                Invite People
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Invite People to Trip</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="friend@email.com"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    className="mt-2"
                  />
                </div>
                <Button onClick={sendInvite} className="w-full">
                  <Mail className="w-4 h-4 mr-2" />
                  Send Invitation
                </Button>
                
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-gray-200 dark:border-gray-800" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white dark:bg-gray-900 px-2 text-gray-500">Or share link</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Input value={tripLink} readOnly />
                  <Button variant="outline" onClick={copyLink}>
                    {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
                
                <Button variant="outline" onClick={shareToWhatsApp} className="w-full">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share via WhatsApp
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Share Card */}
        <Card className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border-blue-200 dark:border-blue-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <LinkIcon className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-900 dark:text-white">Trip Link</p>
                <p className="text-xs text-gray-600 dark:text-gray-400 font-mono">{tripLink}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={copyLink}>
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
              <Button size="sm" onClick={shareToWhatsApp}>
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Proposals */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Trip Proposals
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-6">
              Vote on suggestions from your travel group
            </p>

            <div className="space-y-4">
              {proposals.map((proposal, index) => (
                <motion.div
                  key={proposal.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                >
                  <Card className="p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-start gap-4">
                      <div className="flex flex-col items-center gap-1">
                        <Button
                          variant={proposal.userVote === 'up' ? 'default' : 'ghost'}
                          size="sm"
                          className="h-8 w-8 p-0"
                          onClick={() => handleVote(proposal.id, 'up')}
                        >
                          <ThumbsUp className="w-4 h-4" />
                        </Button>
                        <span className="text-sm font-semibold text-gray-900 dark:text-white">
                          {proposal.votes.up - proposal.votes.down}
                        </span>
                        <Button
                          variant={proposal.userVote === 'down' ? 'destructive' : 'ghost'}
                          size="sm"
                          className="h-8 w-8 p-0"
                          onClick={() => handleVote(proposal.id, 'down')}
                        >
                          <ThumbsDown className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline" className="capitalize">
                            {proposal.type}
                          </Badge>
                          <span className="text-sm text-gray-600 dark:text-gray-400">
                            by {proposal.proposedBy}
                          </span>
                        </div>
                        <h4 className="font-semibold text-gray-900 dark:text-white mb-1">
                          {proposal.item}
                        </h4>
                        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                          <span className="font-semibold text-blue-600 dark:text-blue-400">
                            ${proposal.price}
                          </span>
                          <button className="flex items-center gap-1 hover:text-gray-900 dark:hover:text-white">
                            <MessageSquare className="w-4 h-4" />
                            {proposal.comments} comments
                          </button>
                        </div>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </div>

            <Button variant="outline" className="w-full mt-4">
              <UserPlus className="w-4 h-4 mr-2" />
              Add New Proposal
            </Button>
          </Card>

          {/* Comments Section */}
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              Recent Comments
            </h3>
            <div className="space-y-4">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <Avatar>
                    <AvatarImage src={comment.avatar} />
                    <AvatarFallback>{comment.author[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
                      <p className="text-sm font-semibold text-gray-900 dark:text-white mb-1">
                        {comment.author}
                      </p>
                      <p className="text-sm text-gray-700 dark:text-gray-300">
                        {comment.text}
                      </p>
                    </div>
                    <p className="text-xs text-gray-500 mt-1 ml-3">{comment.timestamp}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 flex gap-2">
              <Input placeholder="Add a comment..." />
              <Button>Send</Button>
            </div>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-1">
          <Card className="p-6 sticky top-24">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
              <Users className="w-5 h-5" />
              Trip Members ({tripMembers.length})
            </h3>
            
            <div className="space-y-3">
              {tripMembers.map((member) => (
                <div key={member.id} className="flex items-center gap-3">
                  <div className="relative">
                    <Avatar>
                      <AvatarImage src={member.avatar} />
                      <AvatarFallback>{member.name[0]}</AvatarFallback>
                    </Avatar>
                    {member.status === 'online' && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-gray-900 rounded-full" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">
                      {member.name}
                    </p>
                    <p className="text-xs text-gray-600 dark:text-gray-400 truncate">
                      {member.email}
                    </p>
                  </div>
                  <Badge variant={member.role === 'Organizer' ? 'default' : 'secondary'}>
                    {member.role}
                  </Badge>
                </div>
              ))}
            </div>

            <Button variant="outline" className="w-full mt-4" onClick={() => setShowInviteModal(true)}>
              <UserPlus className="w-4 h-4 mr-2" />
              Add Member
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
