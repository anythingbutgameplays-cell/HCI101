import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import { motion } from 'motion/react';
import {
  Plane,
  Hotel,
  TrendingDown,
  Calendar,
  MapPin,
  DollarSign,
  Cloud,
  Sun,
  Sparkles,
  ArrowRight,
  Bell,
  ChevronRight
} from 'lucide-react';
import toast from 'react-hot-toast';

const upcomingTrip = {
  destination: 'Paris, France',
  image: 'https://images.unsplash.com/photo-1595441857632-71570ef36580?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyJTIwdHJhdmVsfGVufDF8fHx8MTc3MTUyODY3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
  dates: 'Mar 15 - Mar 22, 2026',
  daysUntil: 23,
  budget: {
    total: 5000,
    spent: 2692
  },
  weather: {
    temp: 68,
    condition: 'Partly Cloudy',
    high: 72,
    low: 58
  }
};

const priceAlerts = [
  {
    id: 1,
    destination: 'Tokyo, Japan',
    type: 'flight',
    oldPrice: 899,
    newPrice: 854,
    savings: 45
  },
  {
    id: 2,
    destination: 'Santorini, Greece',
    type: 'hotel',
    oldPrice: 299,
    newPrice: 249,
    savings: 50
  }
];

const quickActions = [
  { icon: Search, label: 'Search Flights', path: '/search', color: 'blue' },
  { icon: Hotel, label: 'Find Hotels', path: '/search', color: 'green' },
  { icon: Sparkles, label: 'AI Planner', path: '/ai-planner', color: 'purple' },
  { icon: Calendar, label: 'My Trips', path: '/trips', color: 'orange' }
];

function Search(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.35-4.35" />
    </svg>
  );
}

export function Dashboard() {
  const navigate = useNavigate();
  const [expandedCard, setExpandedCard] = useState<string | null>(null);
  
  const currentHour = new Date().getHours();
  const greeting = currentHour < 12 ? 'Good morning' : currentHour < 18 ? 'Good afternoon' : 'Good evening';

  const handlePriceAlert = (alert: typeof priceAlerts[0]) => {
    toast.success(`Price tracked! We'll notify you of any changes.`, {
      duration: 3000,
      icon: '🔔',
    });
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          {greeting}, Alex 👋
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          Your next adventure awaits
        </p>
      </div>

      {/* Upcoming Trip Countdown */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card 
          className="relative overflow-hidden cursor-pointer group"
          onClick={() => navigate('/trips')}
        >
          <div className="absolute inset-0">
            <img
              src={upcomingTrip.image}
              alt={upcomingTrip.destination}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />
          </div>
          
          <div className="relative p-8 text-white">
            <Badge className="mb-4 bg-blue-600">Upcoming Trip</Badge>
            <h2 className="text-4xl font-bold mb-2">{upcomingTrip.destination}</h2>
            <p className="text-lg text-white/90 mb-6">{upcomingTrip.dates}</p>
            
            <div className="flex items-center gap-8">
              <div className="text-center">
                <p className="text-5xl font-bold">{upcomingTrip.daysUntil}</p>
                <p className="text-sm text-white/80 mt-1">Days to go</p>
              </div>
              
              <div className="flex-1 space-y-4">
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm">Budget Progress</span>
                    <span className="text-sm font-semibold">
                      ${upcomingTrip.budget.spent} / ${upcomingTrip.budget.total}
                    </span>
                  </div>
                  <Progress 
                    value={(upcomingTrip.budget.spent / upcomingTrip.budget.total) * 100} 
                    className="h-2"
                  />
                </div>
              </div>
            </div>

            <Button 
              className="mt-6 bg-white text-gray-900 hover:bg-gray-100"
              onClick={(e) => {
                e.stopPropagation();
                navigate('/trips');
              }}
            >
              View Trip Details
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </Card>
      </motion.div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action, index) => {
          const Icon = action.icon;
          const colorClasses = {
            blue: 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400',
            green: 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400',
            purple: 'bg-purple-100 dark:bg-purple-900/30 text-purple-600 dark:text-purple-400',
            orange: 'bg-orange-100 dark:bg-orange-900/30 text-orange-600 dark:text-orange-400'
          };

          return (
            <motion.div
              key={action.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card
                className="p-6 cursor-pointer hover:shadow-lg transition-all group"
                onClick={() => navigate(action.path)}
              >
                <div className={`w-12 h-12 rounded-xl ${colorClasses[action.color as keyof typeof colorClasses]} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                  {action.label}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 flex items-center">
                  Get started
                  <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </p>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weather Preview */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                  Weather Preview
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {upcomingTrip.destination}
                </p>
              </div>
              <Cloud className="w-8 h-8 text-gray-400" />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="text-5xl font-bold text-gray-900 dark:text-white mb-2">
                  {upcomingTrip.weather.temp}°F
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  {upcomingTrip.weather.condition}
                </p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400 mb-1">
                  <span>↑</span>
                  <span>{upcomingTrip.weather.high}°F</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                  <span>↓</span>
                  <span>{upcomingTrip.weather.low}°F</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-2 mt-6 pt-6 border-t border-gray-200 dark:border-gray-800">
              {['Mon', 'Tue', 'Wed', 'Thu'].map((day, index) => (
                <div key={day} className="text-center">
                  <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">{day}</p>
                  <Sun className="w-5 h-5 mx-auto text-yellow-500 mb-1" />
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">
                    {68 + index}°
                  </p>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Price Alerts */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                  Price Alerts
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Recent price drops
                </p>
              </div>
              <TrendingDown className="w-6 h-6 text-green-500" />
            </div>

            <div className="space-y-4">
              {priceAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="p-4 bg-green-50 dark:bg-green-900/10 rounded-xl border border-green-200 dark:border-green-900/30"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white mb-1">
                        {alert.destination}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                        {alert.type}
                      </p>
                    </div>
                    <Badge className="bg-green-600">
                      -${alert.savings}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-3 mb-3">
                    <span className="text-sm text-gray-500 dark:text-gray-400 line-through">
                      ${alert.oldPrice}
                    </span>
                    <span className="text-xl font-bold text-green-600 dark:text-green-400">
                      ${alert.newPrice}
                    </span>
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        window.open(alert.type === 'flight' ? 'https://www.skyscanner.com' : 'https://www.booking.com', '_blank');
                      }}
                    >
                      Book Now
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handlePriceAlert(alert)}
                    >
                      <Bell className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <Button variant="ghost" className="w-full mt-4">
              View All Alerts
            </Button>
          </Card>
        </motion.div>
      </div>

      {/* Recent Activity / Recommendations */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.6 }}
      >
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Recommended Destinations
            </h3>
            <Button variant="ghost" size="sm" onClick={() => navigate('/explore')}>
              View All
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                name: 'Tokyo, Japan',
                image: 'https://images.unsplash.com/photo-1648871647634-0c99b483cb63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b2t5byUyMGphcGFuJTIwY2l0eXNjYXBlfGVufDF8fHx8MTc3MTQ5OTA5MHww&ixlib=rb-4.1.0&q=80&w=1080',
                price: 854,
                tag: 'Trending'
              },
              {
                name: 'Santorini, Greece',
                image: 'https://images.unsplash.com/photo-1497339047006-39f2b26f005d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBncmVlY2UlMjB3aGl0ZSUyMGJ1aWxkaW5nc3xlbnwxfHx8fDE3NzE0ODgwNTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
                price: 699,
                tag: 'Popular'
              },
              {
                name: 'New York, USA',
                image: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXclMjB5b3JrJTIwY2l0eSUyMHNreWxpbmV8ZW58MXx8fHwxNzcxNTIwMDQxfDA&ixlib=rb-4.1.0&q=80&w=1080',
                price: 499,
                tag: 'Best Value'
              }
            ].map((dest) => (
              <Card
                key={dest.name}
                className="overflow-hidden cursor-pointer hover:shadow-xl transition-all group"
                onClick={() => navigate(`/search?destination=${encodeURIComponent(dest.name)}`)}
              >
                <div className="relative h-40 overflow-hidden">
                  <img
                    src={dest.image}
                    alt={dest.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <Badge className="absolute top-3 right-3 bg-blue-600">
                    {dest.tag}
                  </Badge>
                </div>
                <div className="p-4">
                  <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                    {dest.name}
                  </h4>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600 dark:text-gray-400">From</span>
                    <span className="text-lg font-bold text-blue-600 dark:text-blue-400">
                      ${dest.price}
                    </span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
