import { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { ArrowLeft, MapPin, Calendar, Users, ExternalLink } from 'lucide-react';

const destinationData = {
  'Paris, France': {
    image: 'https://images.unsplash.com/photo-1595441857632-71570ef36580?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyJTIwdHJhdmVsfGVufDF8fHx8MTc3MTUyODY3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'The City of Light beckons with its iconic landmarks, world-class museums, and romantic atmosphere.',
    highlights: ['Eiffel Tower', 'Louvre Museum', 'Notre-Dame', 'Arc de Triomphe'],
    activities: [
      { name: 'Seine River Cruise', duration: '2 hours', price: 45 },
      { name: 'Louvre Museum Tour', duration: '3 hours', price: 65 },
      { name: 'Montmartre Walking Tour', duration: '2.5 hours', price: 35 },
      { name: 'Eiffel Tower Summit', duration: '1.5 hours', price: 55 }
    ],
    mapEmbedUrl: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d83998.9!2d2.3522!3d48.8566!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66e1f06e2b411%3A0x40b82c3688c9460!2sParis%2C%20France!5e0!3m2!1sen!2sus!4v1234567890'
  }
};

export function DestinationDetails() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const destinationName = searchParams.get('name') || 'Paris, France';
  const destination = destinationData[destinationName as keyof typeof destinationData] || destinationData['Paris, France'];
  const [showMapModal, setShowMapModal] = useState(false);

  const openGoogleMaps = () => {
    window.open(`https://maps.google.com/?q=${encodeURIComponent(destinationName)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate('/')}>
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold flex-1">{destinationName}</h1>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero Image */}
        <div className="relative h-96 rounded-2xl overflow-hidden mb-8">
          <img
            src={destination.image}
            alt={destinationName}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
            <h2 className="text-4xl font-bold mb-2">{destinationName}</h2>
            <p className="text-lg text-white/90">{destination.description}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="activities" className="w-full">
              <TabsList className="w-full">
                <TabsTrigger value="activities" className="flex-1">Activities</TabsTrigger>
                <TabsTrigger value="highlights" className="flex-1">Highlights</TabsTrigger>
                <TabsTrigger value="map" className="flex-1">Map</TabsTrigger>
              </TabsList>

              <TabsContent value="activities" className="mt-6">
                <div className="space-y-4">
                  {destination.activities.map((activity, index) => (
                    <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold mb-2">{activity.name}</h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {activity.duration}
                            </div>
                            <Badge variant="secondary">${activity.price}</Badge>
                          </div>
                        </div>
                        <Button>Book Now</Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="highlights" className="mt-6">
                <Card className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Must-See Attractions</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {destination.highlights.map((highlight, index) => (
                      <div key={index} className="flex items-center gap-3 p-4 bg-gray-50 rounded-lg">
                        <MapPin className="w-5 h-5 text-blue-600" />
                        <span className="font-medium">{highlight}</span>
                      </div>
                    ))}
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="map" className="mt-6">
                <Card className="p-6">
                  <div className="mb-4 flex items-center justify-between">
                    <h3 className="text-xl font-semibold">Explore Location</h3>
                    <Button variant="outline" onClick={openGoogleMaps}>
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Open in Google Maps
                    </Button>
                  </div>
                  <div className="aspect-video bg-gray-200 rounded-lg overflow-hidden">
                    <iframe
                      src={destination.mapEmbedUrl}
                      width="100%"
                      height="100%"
                      style={{ border: 0 }}
                      allowFullScreen
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                    />
                  </div>
                  <p className="mt-4 text-sm text-gray-600">
                    Click the button above to view interactive map with nearby attractions, restaurants, and hotels.
                  </p>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-6">
              <h3 className="text-xl font-semibold mb-4">Plan Your Trip</h3>
              
              <div className="space-y-4">
                <Button 
                  className="w-full" 
                  size="lg"
                  onClick={() => navigate(`/flights?destination=${encodeURIComponent(destinationName)}`)}
                >
                  Find Flights
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full" 
                  size="lg"
                  onClick={() => navigate(`/hotels?destination=${encodeURIComponent(destinationName)}`)}
                >
                  Find Hotels
                </Button>

                <div className="pt-4 border-t">
                  <h4 className="font-semibold mb-3">Quick Facts</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Best Time to Visit</span>
                      <span className="font-medium">Apr - Oct</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Average Temperature</span>
                      <span className="font-medium">68°F</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Currency</span>
                      <span className="font-medium">EUR (€)</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Language</span>
                      <span className="font-medium">French</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <Button 
                    variant="secondary" 
                    className="w-full"
                    onClick={() => navigate('/dashboard')}
                  >
                    Save to My Trips
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
