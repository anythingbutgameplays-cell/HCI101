import { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router';
import { FlightCard } from '../components/FlightCard';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Slider } from '../components/ui/slider';
import { Checkbox } from '../components/ui/checkbox';
import { Label } from '../components/ui/label';
import { ArrowLeft, SlidersHorizontal } from 'lucide-react';

const mockFlights = [
  {
    airline: 'United Airlines',
    logo: '🛫',
    departure: 'JFK',
    arrival: 'CDG',
    departureTime: '10:30',
    arrivalTime: '22:45',
    duration: '7h 15m',
    stops: 0,
    price: 599,
    dealType: 'Best Value'
  },
  {
    airline: 'Air France',
    logo: '✈️',
    departure: 'JFK',
    arrival: 'CDG',
    departureTime: '18:15',
    arrivalTime: '07:30',
    duration: '8h 15m',
    stops: 0,
    price: 649
  },
  {
    airline: 'Delta',
    logo: '🛩️',
    departure: 'JFK',
    arrival: 'CDG',
    departureTime: '14:00',
    arrivalTime: '03:20',
    duration: '8h 20m',
    stops: 1,
    price: 449,
    dealType: 'Cheapest'
  },
  {
    airline: 'British Airways',
    logo: '🛫',
    departure: 'JFK',
    arrival: 'CDG',
    departureTime: '20:30',
    arrivalTime: '09:45',
    duration: '8h 15m',
    stops: 1,
    price: 479
  },
  {
    airline: 'Lufthansa',
    logo: '✈️',
    departure: 'JFK',
    arrival: 'CDG',
    departureTime: '16:45',
    arrivalTime: '06:10',
    duration: '8h 25m',
    stops: 1,
    price: 519
  }
];

export function FlightResults() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const destination = searchParams.get('destination') || 'Paris';
  
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [showNonstop, setShowNonstop] = useState(false);
  const [selectedAirlines, setSelectedAirlines] = useState<string[]>([]);

  const airlines = [...new Set(mockFlights.map(f => f.airline))];

  const filteredFlights = mockFlights.filter(flight => {
    if (flight.price < priceRange[0] || flight.price > priceRange[1]) return false;
    if (showNonstop && flight.stops > 0) return false;
    if (selectedAirlines.length > 0 && !selectedAirlines.includes(flight.airline)) return false;
    return true;
  });

  const toggleAirline = (airline: string) => {
    setSelectedAirlines(prev =>
      prev.includes(airline)
        ? prev.filter(a => a !== airline)
        : [...prev, airline]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate('/')}>
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl font-bold">Flights to {destination}</h1>
              <p className="text-sm text-gray-600">{filteredFlights.length} flights found</p>
            </div>
            <Button variant="outline" onClick={() => navigate('/hotels' + window.location.search)}>
              View Hotels Instead
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-6">
              <div className="flex items-center gap-2 mb-6">
                <SlidersHorizontal className="w-5 h-5" />
                <h2 className="text-lg font-semibold">Filters</h2>
              </div>

              <div className="space-y-6">
                {/* Price Range */}
                <div>
                  <Label className="text-sm font-semibold mb-3 block">Price Range</Label>
                  <Slider
                    min={0}
                    max={1000}
                    step={50}
                    value={priceRange}
                    onValueChange={setPriceRange}
                    className="mb-2"
                  />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}</span>
                  </div>
                </div>

                {/* Stops */}
                <div>
                  <Label className="text-sm font-semibold mb-3 block">Stops</Label>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="nonstop"
                      checked={showNonstop}
                      onCheckedChange={(checked) => setShowNonstop(checked as boolean)}
                    />
                    <Label htmlFor="nonstop" className="cursor-pointer">
                      Nonstop only
                    </Label>
                  </div>
                </div>

                {/* Airlines */}
                <div>
                  <Label className="text-sm font-semibold mb-3 block">Airlines</Label>
                  <div className="space-y-2">
                    {airlines.map(airline => (
                      <div key={airline} className="flex items-center space-x-2">
                        <Checkbox
                          id={airline}
                          checked={selectedAirlines.includes(airline)}
                          onCheckedChange={() => toggleAirline(airline)}
                        />
                        <Label htmlFor={airline} className="cursor-pointer text-sm">
                          {airline}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setPriceRange([0, 1000]);
                    setShowNonstop(false);
                    setSelectedAirlines([]);
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            </Card>
          </div>

          {/* Flight Results */}
          <div className="lg:col-span-3 space-y-4">
            {filteredFlights.length === 0 ? (
              <Card className="p-12 text-center">
                <p className="text-lg text-gray-600">No flights match your filters</p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setPriceRange([0, 1000]);
                    setShowNonstop(false);
                    setSelectedAirlines([]);
                  }}
                >
                  Clear Filters
                </Button>
              </Card>
            ) : (
              filteredFlights.map((flight, index) => (
                <FlightCard key={index} {...flight} />
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
