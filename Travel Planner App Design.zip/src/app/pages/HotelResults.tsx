import { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router';
import { HotelCard } from '../components/HotelCard';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Slider } from '../components/ui/slider';
import { Checkbox } from '../components/ui/checkbox';
import { Label } from '../components/ui/label';
import { ArrowLeft, SlidersHorizontal, Star } from 'lucide-react';

const mockHotels = [
  {
    name: 'Grand Palace Hotel',
    image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb218ZW58MXx8fHwxNzcxNDQ0ODUzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Downtown, 0.5 mi to center',
    rating: 5,
    reviews: 1289,
    amenities: ['WiFi', 'Breakfast', 'Pool', 'AC'],
    price: 299,
    dealType: 'Top Rated'
  },
  {
    name: 'Seaside Resort & Spa',
    image: 'https://images.unsplash.com/photo-1637730827702-de34e9ae4ede?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBob3RlbCUyMGxvYmJ5fGVufDF8fHx8MTc3MTQ3MjE0MXww&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Beach Area, 2 mi to center',
    rating: 5,
    reviews: 856,
    amenities: ['WiFi', 'Breakfast', 'Pool'],
    price: 349
  },
  {
    name: 'Urban Boutique Hotel',
    image: 'https://images.unsplash.com/photo-1731336478850-6bce7235e320?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3V0aXF1ZSUyMGhvdGVsJTIwYmVkcm9vbXxlbnwxfHx8fDE3NzE0NjM0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'City Center, 0.2 mi to center',
    rating: 4,
    reviews: 542,
    amenities: ['WiFi', 'Breakfast', 'AC'],
    price: 189,
    dealType: 'Best Price'
  },
  {
    name: 'Riverside Luxury Suites',
    image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb218ZW58MXx8fHwxNzcxNDQ0ODUzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Riverside, 1 mi to center',
    rating: 5,
    reviews: 723,
    amenities: ['WiFi', 'Pool', 'AC'],
    price: 279
  },
  {
    name: 'Cozy Inn Downtown',
    image: 'https://images.unsplash.com/photo-1731336478850-6bce7235e320?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3V0aXF1ZSUyMGhvdGVsJTIwYmVkcm9vbXxlbnwxfHx8fDE3NzE0NjM0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Downtown, 0.3 mi to center',
    rating: 4,
    reviews: 389,
    amenities: ['WiFi', 'Breakfast'],
    price: 149
  },
  {
    name: 'Modern City Hotel',
    image: 'https://images.unsplash.com/photo-1637730827702-de34e9ae4ede?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBob3RlbCUyMGxvYmJ5fGVufDF8fHx8MTc3MTQ3MjE0MXww&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Business District, 1.5 mi to center',
    rating: 4,
    reviews: 612,
    amenities: ['WiFi', 'AC'],
    price: 199
  }
];

export function HotelResults() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const destination = searchParams.get('destination') || 'Paris';
  
  const [priceRange, setPriceRange] = useState([0, 500]);
  const [minRating, setMinRating] = useState(0);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);

  const amenitiesList = ['WiFi', 'Breakfast', 'Pool', 'AC'];

  const filteredHotels = mockHotels.filter(hotel => {
    if (hotel.price < priceRange[0] || hotel.price > priceRange[1]) return false;
    if (hotel.rating < minRating) return false;
    if (selectedAmenities.length > 0) {
      const hasAllAmenities = selectedAmenities.every(amenity => 
        hotel.amenities.includes(amenity)
      );
      if (!hasAllAmenities) return false;
    }
    return true;
  });

  const toggleAmenity = (amenity: string) => {
    setSelectedAmenities(prev =>
      prev.includes(amenity)
        ? prev.filter(a => a !== amenity)
        : [...prev, amenity]
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate('/')}>
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
            <div className="flex-1">
              <h1 className="text-2xl font-bold">Hotels in {destination}</h1>
              <p className="text-sm text-gray-600">{filteredHotels.length} properties found</p>
            </div>
            <Button variant="outline" onClick={() => navigate('/flights' + window.location.search)}>
              View Flights Instead
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 sticky top-6">
              <div className="flex items-center gap-2 mb-6">
                <SlidersHorizontal className="w-5 h-5" />
                <h2 className="text-lg font-semibold">Filters</h2>
              </div>

              <div className="space-y-6">
                {/* Price Range */}
                <div>
                  <Label className="text-sm font-semibold mb-3 block">Price per Night</Label>
                  <Slider
                    min={0}
                    max={500}
                    step={25}
                    value={priceRange}
                    onValueChange={setPriceRange}
                    className="mb-2"
                  />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>${priceRange[0]}</span>
                    <span>${priceRange[1]}</span>
                  </div>
                </div>

                {/* Rating */}
                <div>
                  <Label className="text-sm font-semibold mb-3 block">Minimum Rating</Label>
                  <div className="space-y-2">
                    {[5, 4, 3].map(rating => (
                      <div key={rating} className="flex items-center space-x-2">
                        <Checkbox
                          id={`rating-${rating}`}
                          checked={minRating === rating}
                          onCheckedChange={() => setMinRating(minRating === rating ? 0 : rating)}
                        />
                        <Label htmlFor={`rating-${rating}`} className="cursor-pointer flex items-center gap-1">
                          {[...Array(rating)].map((_, i) => (
                            <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          ))}
                          <span className="text-sm ml-1">& up</span>
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Amenities */}
                <div>
                  <Label className="text-sm font-semibold mb-3 block">Amenities</Label>
                  <div className="space-y-2">
                    {amenitiesList.map(amenity => (
                      <div key={amenity} className="flex items-center space-x-2">
                        <Checkbox
                          id={amenity}
                          checked={selectedAmenities.includes(amenity)}
                          onCheckedChange={() => toggleAmenity(amenity)}
                        />
                        <Label htmlFor={amenity} className="cursor-pointer text-sm">
                          {amenity}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setPriceRange([0, 500]);
                    setMinRating(0);
                    setSelectedAmenities([]);
                  }}
                >
                  Reset Filters
                </Button>
              </div>
            </Card>
          </div>

          {/* Hotel Results */}
          <div className="lg:col-span-3">
            {filteredHotels.length === 0 ? (
              <Card className="p-12 text-center">
                <p className="text-lg text-gray-600">No hotels match your filters</p>
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => {
                    setPriceRange([0, 500]);
                    setMinRating(0);
                    setSelectedAmenities([]);
                  }}
                >
                  Clear Filters
                </Button>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredHotels.map((hotel, index) => (
                  <HotelCard key={index} {...hotel} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
