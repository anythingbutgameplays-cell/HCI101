import { SearchForm } from '../components/SearchForm';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { useNavigate } from 'react-router';
import { Plane, Hotel, Map, TrendingUp } from 'lucide-react';

const popularDestinations = [
  {
    name: 'Paris, France',
    image: 'https://images.unsplash.com/photo-1595441857632-71570ef36580?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyJTIwdHJhdmVsfGVufDF8fHx8MTc3MTUyODY3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    price: 599,
    description: 'City of Light'
  },
  {
    name: 'Tokyo, Japan',
    image: 'https://images.unsplash.com/photo-1648871647634-0c99b483cb63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b2t5byUyMGphcGFuJTIwY2l0eXNjYXBlfGVufDF8fHx8MTc3MTQ5OTA5MHww&ixlib=rb-4.1.0&q=80&w=1080',
    price: 899,
    description: 'Modern Metropolis'
  },
  {
    name: 'Santorini, Greece',
    image: 'https://images.unsplash.com/photo-1497339047006-39f2b26f005d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBncmVlY2UlMjB3aGl0ZSUyMGJ1aWxkaW5nc3xlbnwxfHx8fDE3NzE0ODgwNTF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    price: 699,
    description: 'Island Paradise'
  },
  {
    name: 'New York, USA',
    image: 'https://images.unsplash.com/photo-1514565131-fce0801e5785?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXclMjB5b3JrJTIwY2l0eSUyMHNreWxpbmV8ZW58MXx8fHwxNzcxNTIwMDQxfDA&ixlib=rb-4.1.0&q=80&w=1080',
    price: 499,
    description: 'The Big Apple'
  }
];

const features = [
  {
    icon: <Plane className="w-8 h-8" />,
    title: 'Find Flights',
    description: 'Compare prices from top airlines'
  },
  {
    icon: <Hotel className="w-8 h-8" />,
    title: 'Book Hotels',
    description: 'Thousands of accommodations worldwide'
  },
  {
    icon: <Map className="w-8 h-8" />,
    title: 'Plan Routes',
    description: 'Interactive maps and itineraries'
  },
  {
    icon: <TrendingUp className="w-8 h-8" />,
    title: 'Best Deals',
    description: 'Save up to 70% on bookings'
  }
];

export function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-orange-50">
      {/* Hero Section */}
      <div className="relative h-[600px] overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1660289647786-bfa5e9e8ba16?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcGFyYWRpc2UlMjBkZXN0aW5hdGlvbnxlbnwxfHx8fDE3NzE0NDgyMDJ8MA&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Travel Destination"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-transparent" />
        
        <div className="relative max-w-7xl mx-auto px-4 pt-32">
          <div className="text-center mb-12">
            <h1 className="text-6xl font-bold text-white mb-4">
              Your Journey Starts Here
            </h1>
            <p className="text-2xl text-white/90">
              Discover amazing destinations and book with confidence
            </p>
          </div>
          
          <SearchForm />
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 py-20">
        <h2 className="text-4xl font-bold text-center mb-12">Why Choose TravelPlan?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature) => (
            <Card key={feature.title} className="p-6 text-center hover:shadow-lg transition-shadow">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 text-blue-600 rounded-full mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>

      {/* Popular Destinations */}
      <div className="max-w-7xl mx-auto px-4 pb-20">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-4xl font-bold">Popular Destinations</h2>
          <Button variant="outline" onClick={() => navigate('/dashboard')}>
            View My Trips
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {popularDestinations.map((dest) => (
            <Card
              key={dest.name}
              className="overflow-hidden cursor-pointer hover:shadow-xl transition-all group"
              onClick={() => navigate(`/destination?name=${encodeURIComponent(dest.name)}`)}
            >
              <div className="relative h-64 overflow-hidden">
                <img
                  src={dest.image}
                  alt={dest.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                  <h3 className="text-xl font-bold mb-1">{dest.name}</h3>
                  <p className="text-sm text-white/80 mb-2">{dest.description}</p>
                  <p className="text-lg font-semibold">From ${dest.price}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
