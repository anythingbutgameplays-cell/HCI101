import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Calendar } from '../components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '../components/ui/popover';
import { Badge } from '../components/ui/badge';
import { Slider } from '../components/ui/slider';
import { Checkbox } from '../components/ui/checkbox';
import { Label } from '../components/ui/label';
import { FlightCard } from '../components/FlightCard';
import { HotelCard } from '../components/HotelCard';
import {
  MapPin,
  Calendar as CalendarIcon,
  Users,
  Search,
  SlidersHorizontal,
  Map as MapIcon,
  List,
  TrendingUp,
  ExternalLink
} from 'lucide-react';
import { format } from 'date-fns';
import { motion } from 'motion/react';

const mockFlights = [
  {
    airline: 'United Airlines',
    logo: '🛫',
    departure: 'JFK',
    arrival: 'CDG',
    departureTime: '10:30',
    arrivalTime: '22:45',
    duration: '7h 15m',
    stops: 0,
    price: 599,
    dealType: 'Best Value'
  },
  {
    airline: 'Air France',
    logo: '✈️',
    departure: 'JFK',
    arrival: 'CDG',
    departureTime: '18:15',
    arrivalTime: '07:30',
    duration: '8h 15m',
    stops: 0,
    price: 649
  },
  {
    airline: 'Delta',
    logo: '🛩️',
    departure: 'JFK',
    arrival: 'CDG',
    departureTime: '14:00',
    arrivalTime: '03:20',
    duration: '8h 20m',
    stops: 1,
    price: 449,
    dealType: 'Cheapest'
  },
];

const mockHotels = [
  {
    name: 'Grand Palace Hotel',
    image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHJvb218ZW58MXx8fHwxNzcxNDQ0ODUzfDA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Downtown, 0.5 mi to center',
    rating: 5,
    reviews: 1289,
    amenities: ['WiFi', 'Breakfast', 'Pool', 'AC'],
    price: 299,
    dealType: 'Top Rated'
  },
  {
    name: 'Seaside Resort & Spa',
    image: 'https://images.unsplash.com/photo-1637730827702-de34e9ae4ede?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBob3RlbCUyMGxvYmJ5fGVufDF8fHx8MTc3MTQ3MjE0MXww&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'Beach Area, 2 mi to center',
    rating: 5,
    reviews: 856,
    amenities: ['WiFi', 'Breakfast', 'Pool'],
    price: 349
  },
  {
    name: 'Urban Boutique Hotel',
    image: 'https://images.unsplash.com/photo-1731336478850-6bce7235e320?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3V0aXF1ZSUyMGhvdGVsJTIwYmVkcm9vbXxlbnwxfHx8fDE3NzE0NjM0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080',
    location: 'City Center, 0.2 mi to center',
    rating: 4,
    reviews: 542,
    amenities: ['WiFi', 'Breakfast', 'AC'],
    price: 189,
    dealType: 'Best Price'
  },
];

const priceTrendData = [
  { month: 'Jan', price: 650 },
  { month: 'Feb', price: 580 },
  { month: 'Mar', price: 599 },
  { month: 'Apr', price: 720 },
  { month: 'May', price: 680 },
  { month: 'Jun', price: 750 },
];

export function SearchPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialDestination = searchParams.get('destination') || '';

  const [destination, setDestination] = useState(initialDestination);
  const [searchType, setSearchType] = useState<'flights' | 'hotels'>('flights');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [checkIn, setCheckIn] = useState<Date>();
  const [checkOut, setCheckOut] = useState<Date>();
  const [travelers, setTravelers] = useState('2');
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [showFilters, setShowFilters] = useState(true);

  const results = searchType === 'flights' ? mockFlights : mockHotels;

  return (
    <div className="h-[calc(100vh-4rem)] flex flex-col">
      {/* Search Bar */}
      <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 p-4">
        <div className="flex gap-3">
          <Tabs value={searchType} onValueChange={(v) => setSearchType(v as any)} className="w-48">
            <TabsList className="w-full">
              <TabsTrigger value="flights" className="flex-1">✈️ Flights</TabsTrigger>
              <TabsTrigger value="hotels" className="flex-1">🏨 Hotels</TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex-1 relative">
            <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Where to?"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              className="pl-10 h-11"
            />
          </div>

          <Popover>
            <PopoverTrigger className="h-11">
              <Button variant="outline" className="h-11 justify-start">
                <CalendarIcon className="mr-2 h-5 w-5 text-gray-400" />
                {checkIn ? format(checkIn, 'MMM dd') : 'Check-in'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={checkIn} onSelect={setCheckIn} initialFocus />
            </PopoverContent>
          </Popover>

          <Popover>
            <PopoverTrigger className="h-11">
              <Button variant="outline" className="h-11 justify-start">
                <CalendarIcon className="mr-2 h-5 w-5 text-gray-400" />
                {checkOut ? format(checkOut, 'MMM dd') : 'Check-out'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar mode="single" selected={checkOut} onSelect={setCheckOut} initialFocus />
            </PopoverContent>
          </Popover>

          <Button size="lg" className="px-8">
            <Search className="mr-2 w-5 h-5" />
            Search
          </Button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant={showFilters ? 'default' : 'outline'}
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
          >
            <SlidersHorizontal className="w-4 h-4 mr-2" />
            Filters
          </Button>
          
          <div className="flex gap-2">
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4 mr-2" />
              List
            </Button>
            <Button
              variant={viewMode === 'map' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('map')}
            >
              <MapIcon className="w-4 h-4 mr-2" />
              Map
            </Button>
          </div>

          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              window.open('https://www.google.com/flights', '_blank');
            }}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Compare on Google Flights
          </Button>
        </div>

        <p className="text-sm text-gray-600 dark:text-gray-400">
          {results.length} results found
        </p>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden flex">
        {/* Filters Sidebar */}
        <motion.div
          initial={false}
          animate={{ width: showFilters ? 280 : 0 }}
          className="bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 overflow-hidden"
        >
          <div className="p-4 w-70 space-y-6">
            {/* Price Trend */}
            <div>
              <h3 className="text-sm font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Price Trend
              </h3>
              <div className="h-32 flex items-end gap-2">
                {priceTrendData.map((item, index) => (
                  <div key={item.month} className="flex-1 flex flex-col items-center gap-1">
                    <div
                      className="w-full bg-blue-600 rounded-t hover:bg-blue-700 transition-colors cursor-pointer"
                      style={{ height: `${(item.price / 800) * 100}%` }}
                    />
                    <span className="text-xs text-gray-600 dark:text-gray-400">{item.month}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Price Range */}
            <div>
              <Label className="text-sm font-semibold mb-3 block">Price Range</Label>
              <Slider
                value={priceRange}
                onValueChange={setPriceRange}
                min={0}
                max={1000}
                step={50}
                className="mb-2"
              />
              <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400">
                <span>${priceRange[0]}</span>
                <span>${priceRange[1]}</span>
              </div>
            </div>

            {/* Quick Filters */}
            <div>
              <Label className="text-sm font-semibold mb-3 block">Quick Filters</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox id="nonstop" />
                  <Label htmlFor="nonstop" className="text-sm cursor-pointer">
                    Nonstop only
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="refundable" />
                  <Label htmlFor="refundable" className="text-sm cursor-pointer">
                    Refundable
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="wifi" />
                  <Label htmlFor="wifi" className="text-sm cursor-pointer">
                    Free WiFi
                  </Label>
                </div>
              </div>
            </div>

            <Button variant="outline" className="w-full">
              Reset Filters
            </Button>
          </div>
        </motion.div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto p-6 bg-gray-50 dark:bg-gray-950">
          {viewMode === 'list' ? (
            <div className="max-w-5xl mx-auto space-y-4">
              {searchType === 'flights' ? (
                mockFlights.map((flight, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                  >
                    <FlightCard {...flight} />
                  </motion.div>
                ))
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {mockHotels.map((hotel, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <HotelCard {...hotel} />
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="h-full relative">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d83998.9!2d2.3522!3d48.8566!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66e1f06e2b411%3A0x40b82c3688c9460!2sParis%2C%20France!5e0!3m2!1sen!2sus!4v1234567890"
                className="w-full h-full rounded-lg"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
              />
              <Button
                className="absolute top-4 right-4"
                onClick={() => window.open('https://maps.google.com', '_blank')}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open in Google Maps
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
