import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Progress } from '../components/ui/progress';
import { 
  ArrowLeft, 
  Plane, 
  Hotel, 
  Calendar, 
  DollarSign, 
  Share2, 
  Download,
  MapPin,
  Sun,
  Cloud
} from 'lucide-react';

const savedTrips = [
  {
    id: 1,
    destination: 'Paris, France',
    dates: 'Mar 15 - Mar 22, 2026',
    image: 'https://images.unsplash.com/photo-1595441857632-71570ef36580?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJpcyUyMGVpZmZlbCUyMHRvd2VyJTIwdHJhdmVsfGVufDF8fHx8MTc3MTUyODY3N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'Upcoming',
    flight: {
      airline: 'United Airlines',
      departure: 'JFK 10:30 AM',
      arrival: 'CDG 10:45 PM',
      price: 599
    },
    hotel: {
      name: 'Grand Palace Hotel',
      nights: 7,
      pricePerNight: 299
    },
    budget: {
      total: 5000,
      spent: 2692,
      categories: [
        { name: 'Flights', amount: 1198, color: 'bg-blue-500' },
        { name: 'Hotel', amount: 2093, color: 'bg-green-500' },
        { name: 'Activities', amount: 0, color: 'bg-purple-500' },
        { name: 'Food', amount: 0, color: 'bg-orange-500' }
      ]
    },
    weather: {
      temp: '68°F',
      condition: 'Partly Cloudy',
      icon: <Cloud className="w-8 h-8" />
    }
  },
  {
    id: 2,
    destination: 'Tokyo, Japan',
    dates: 'Jun 10 - Jun 18, 2026',
    image: 'https://images.unsplash.com/photo-1648871647634-0c99b483cb63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0b2t5byUyMGphcGFuJTIwY2l0eXNjYXBlfGVufDF8fHx8MTc3MTQ5OTA5MHww&ixlib=rb-4.1.0&q=80&w=1080',
    status: 'Planning',
    budget: {
      total: 6000,
      spent: 0,
      categories: []
    }
  }
];

export function TripDashboard() {
  const navigate = useNavigate();
  const [selectedTrip, setSelectedTrip] = useState(savedTrips[0]);

  const shareTrip = () => {
    const text = `Check out my trip to ${selectedTrip.destination}! ${selectedTrip.dates}`;
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const addToCalendar = () => {
    const title = `Trip to ${selectedTrip.destination}`;
    const details = `Flight and hotel booked for ${selectedTrip.destination}`;
    const dates = selectedTrip.dates.split(' - ');
    const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&details=${encodeURIComponent(details)}`;
    window.open(url, '_blank');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => navigate('/')}>
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back
            </Button>
            <h1 className="text-2xl font-bold flex-1">My Trips</h1>
            <Button onClick={() => navigate('/')}>Plan New Trip</Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Trip List Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-4">
              <h2 className="font-semibold mb-4">Your Trips</h2>
              <div className="space-y-3">
                {savedTrips.map(trip => (
                  <Card
                    key={trip.id}
                    className={`p-4 cursor-pointer transition-all ${
                      selectedTrip.id === trip.id
                        ? 'ring-2 ring-blue-600'
                        : 'hover:shadow-md'
                    }`}
                    onClick={() => setSelectedTrip(trip)}
                  >
                    <div className="flex gap-3">
                      <img
                        src={trip.image}
                        alt={trip.destination}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{trip.destination}</h3>
                        <p className="text-sm text-gray-600 mb-2">{trip.dates}</p>
                        <Badge variant={trip.status === 'Upcoming' ? 'default' : 'secondary'}>
                          {trip.status}
                        </Badge>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </Card>
          </div>

          {/* Trip Details */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="relative h-64 rounded-2xl overflow-hidden mb-4">
                <img
                  src={selectedTrip.image}
                  alt={selectedTrip.destination}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                  <h2 className="text-3xl font-bold mb-2">{selectedTrip.destination}</h2>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5" />
                    <span className="text-lg">{selectedTrip.dates}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button onClick={shareTrip} className="flex-1">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share Trip
                </Button>
                <Button onClick={addToCalendar} variant="outline" className="flex-1">
                  <Calendar className="w-4 h-4 mr-2" />
                  Add to Calendar
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="w-full">
                <TabsTrigger value="overview" className="flex-1">Overview</TabsTrigger>
                <TabsTrigger value="budget" className="flex-1">Budget</TabsTrigger>
                <TabsTrigger value="weather" className="flex-1">Weather</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-6 space-y-4">
                {selectedTrip.flight && (
                  <Card className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Plane className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Flight Details</h3>
                        <p className="text-sm text-gray-600">{selectedTrip.flight.airline}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Departure</p>
                        <p className="font-semibold">{selectedTrip.flight.departure}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Arrival</p>
                        <p className="font-semibold">{selectedTrip.flight.arrival}</p>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t flex justify-between items-center">
                      <span className="text-sm text-gray-600">Total Cost</span>
                      <span className="text-xl font-bold text-blue-600">${selectedTrip.flight.price}</span>
                    </div>
                  </Card>
                )}

                {selectedTrip.hotel && (
                  <Card className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <Hotel className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Hotel Reservation</h3>
                        <p className="text-sm text-gray-600">{selectedTrip.hotel.name}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Nights</p>
                        <p className="font-semibold">{selectedTrip.hotel.nights} nights</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Per Night</p>
                        <p className="font-semibold">${selectedTrip.hotel.pricePerNight}</p>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t flex justify-between items-center">
                      <span className="text-sm text-gray-600">Total Cost</span>
                      <span className="text-xl font-bold text-green-600">
                        ${selectedTrip.hotel.nights * selectedTrip.hotel.pricePerNight}
                      </span>
                    </div>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="budget" className="mt-6">
                <Card className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="text-lg font-semibold">Trip Budget</h3>
                      <p className="text-sm text-gray-600">
                        ${selectedTrip.budget.spent.toLocaleString()} of ${selectedTrip.budget.total.toLocaleString()} spent
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-blue-600">
                        {Math.round((selectedTrip.budget.spent / selectedTrip.budget.total) * 100)}%
                      </p>
                      <p className="text-sm text-gray-600">Used</p>
                    </div>
                  </div>

                  <Progress 
                    value={(selectedTrip.budget.spent / selectedTrip.budget.total) * 100} 
                    className="mb-6"
                  />

                  {selectedTrip.budget.categories.length > 0 && (
                    <div className="space-y-4">
                      <h4 className="font-semibold">Budget Breakdown</h4>
                      {selectedTrip.budget.categories.map((category, index) => (
                        <div key={index}>
                          <div className="flex justify-between text-sm mb-2">
                            <span className="font-medium">{category.name}</span>
                            <span className="text-gray-600">${category.amount.toLocaleString()}</span>
                          </div>
                          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${category.color}`}
                              style={{ width: `${(category.amount / selectedTrip.budget.total) * 100}%` }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="mt-6 pt-6 border-t">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold">Remaining Budget</span>
                      <span className="text-2xl font-bold text-green-600">
                        ${(selectedTrip.budget.total - selectedTrip.budget.spent).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="weather" className="mt-6">
                {selectedTrip.weather ? (
                  <Card className="p-6">
                    <h3 className="text-lg font-semibold mb-6">Weather Forecast</h3>
                    <div className="text-center">
                      <div className="inline-flex items-center justify-center w-24 h-24 bg-blue-50 rounded-full mb-4">
                        {selectedTrip.weather.icon}
                      </div>
                      <p className="text-5xl font-bold mb-2">{selectedTrip.weather.temp}</p>
                      <p className="text-xl text-gray-600 mb-6">{selectedTrip.weather.condition}</p>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mt-8">
                      {['Mon', 'Tue', 'Wed'].map((day, index) => (
                        <Card key={day} className="p-4 text-center">
                          <p className="font-semibold mb-2">{day}</p>
                          <Sun className="w-8 h-8 mx-auto mb-2 text-yellow-500" />
                          <p className="text-lg font-semibold">
                            {68 + index}°F
                          </p>
                        </Card>
                      ))}
                    </div>
                  </Card>
                ) : (
                  <Card className="p-12 text-center">
                    <p className="text-gray-600">Weather information will be available closer to your trip date</p>
                  </Card>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}
